package com.service;

import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import com.entity.Product;
import com.exception.ResourceNotFoundException;
import com.repository.ProductRepository;
import java.util.List;
import java.util.Optional;

@Service
@Transactional
public class ProductService {

	private final ProductRepository productRepository;

	public ProductService(ProductRepository productRepository) {
		this.productRepository = productRepository;
	}

	public List<Product> getAllProducts() {
		return productRepository.findAll();
	}

	public Optional<Product> getProductById(Long productId) {
		if (productRepository.existsById(productId)) {
			return productRepository.findById(productId);
		}
		throw new ResourceNotFoundException("Product not found with id : " + productId);
	}

	public Product createProduct(Product product) {
		return productRepository.save(product);
	}

	public Product updateProduct(Long productId, Product updatedProduct) {
		if (productRepository.existsById(productId)) {
			updatedProduct.setId(productId);
			return productRepository.save(updatedProduct);
		}
		throw new ResourceNotFoundException("Product not found with id : " + productId);
	}

	public void deleteProduct(Long productId) {
		productRepository.deleteById(productId);
	}
}