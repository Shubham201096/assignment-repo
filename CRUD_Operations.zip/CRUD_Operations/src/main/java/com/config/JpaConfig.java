package com.config;

import org.springframework.context.annotation.Configuration;
import org.springframework.data.jpa.repository.config.EnableJpaRepositories;

@Configuration
@EnableJpaRepositories(basePackages = "com.example.repository") // Specify the package where your repositories are located
public class JpaConfig {
    // You can include additional JPA-related configurations here if needed
}

