package com.controller;

import java.util.List;
import java.util.Optional;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.*;
import com.entity.Product;
import com.service.ProductService;

@Controller
@RequestMapping("/api/products")
public class crudOperationsController {

	private static final Logger LOGGER = LoggerFactory.getLogger("crudOperationsController");
	
	private final ProductService productService;

	public crudOperationsController(ProductService productService) {
		this.productService = productService;
	}

	@RequestMapping(value = "/getAllProducts", method = RequestMethod.POST)
	public List<Product> getAllProducts() {
		LOGGER.info("Getting all products");
		return productService.getAllProducts();
	}

	@GetMapping("/getProductById/{productId}")
	public ResponseEntity<Product> getProductById(@PathVariable Long productId) {
		LOGGER.info("Getting product by ID");
		Optional<Product> product = productService.getProductById(productId);
		return new ResponseEntity<Product>(product.get(), HttpStatus.OK);

	}

	@PostMapping("/createProduct")
	public ResponseEntity<Product> createProduct(@Validated @RequestBody Product product) {
		LOGGER.info("Creating a product");
		Product createdProduct = productService.createProduct(product);
		return new ResponseEntity<Product>(createdProduct, HttpStatus.CREATED);
	}

	@PutMapping("/updateProduct/{productId}")
	public ResponseEntity<Product> updateProduct(@PathVariable Long productId,
			@Validated @RequestBody Product updatedProduct) {
		try {
			LOGGER.info("Updating a product");
			Product product = productService.updateProduct(productId, updatedProduct);
			return new ResponseEntity<Product>(product, HttpStatus.OK);
		} catch (RuntimeException e) {
			return new ResponseEntity<Product>(HttpStatus.NOT_FOUND);
		}
	}

	@DeleteMapping("/deleteProduct/{productId}")
	public ResponseEntity<Void> deleteProduct(@PathVariable Long productId) {
		LOGGER.info("Deleting a product");
		productService.deleteProduct(productId);
		return new ResponseEntity<Void>(HttpStatus.NO_CONTENT);
	}
}
